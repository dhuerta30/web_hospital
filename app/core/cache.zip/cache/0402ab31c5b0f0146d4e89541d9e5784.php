<footer>
    <div class="wrap">
        <!-- Banda bicolor superior -->
        <div class="bicolor">
            <span class="azul"></span>
            <span class="rojo"></span>
        </div>

        <div class="top">
            <div class="listas">
                <!-- Aquí podrías agregar listas de enlaces u otra información -->

                <div id="sidebar_bottom" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; padding: 14px;">
                    <?php 
                        $env = $_ENV["BASE_URL"];
                        $inferior = App\Controllers\WebController::barra_inferior();
                    ?>

                    <?php foreach($inferior as $infer): ?>
                    <div class="sidebar-wrap widget_media_image">
                        <a href="<?=$infer["url"]?>" target="_blank">
                            <img src="<?= $env ?>app/libs/artify/uploads/<?=$infer["imagen"]?>" alt="" style="width: 100%; height: auto;">
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>


            </div>

            <div class="clearfix"></div>
        </div>

        <div class="bottom">
            <div class="left">
                <span>Hospital San José de Melipilla O´higgins 551</span>
            </div>
            <nav>
                <!-- Navegación del pie de página si es necesario -->
            </nav>
            <div class="clearfix"></div>

            <!-- Banda bicolor inferior -->
            <div class="bicolor">
                <span class="azul"></span>
                <span class="rojo"></span>
            </div>
        </div>
    </div>
</footer>

<!-- Scripts agrupados y ordenados -->
<script src='<?php echo htmlspecialchars($_ENV["BASE_URL"], ENT_QUOTES, 'UTF-8'); ?>js/bootstrap.js'></script>
<script src='<?php echo htmlspecialchars($_ENV["BASE_URL"], ENT_QUOTES, 'UTF-8'); ?>js/main.js'></script>
<script src='<?php echo htmlspecialchars($_ENV["BASE_URL"], ENT_QUOTES, 'UTF-8'); ?>js/fancybox.umd.js'></script>
</body>
</html>
